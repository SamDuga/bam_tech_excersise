﻿using Dapper;
using MediatR;
using MediatR.Pipeline;
using Microsoft.EntityFrameworkCore;
using StargateAPI.Business.Data;
using StargateAPI.Controllers;
using System.Numerics;

namespace StargateAPI.Business.Commands
{
    public class UpdatePerson : IRequest<UpdatePersonResult>
    {
        public required string CurrentName { get; set; } = string.Empty;
        public required string NewName {  get; set; } = string.Empty;
    }

    public class UpdatePersonPreProcessor : IRequestPreProcessor<UpdatePerson>
    {
        private readonly StargateContext _context;
        public UpdatePersonPreProcessor(StargateContext context)
        {
            _context = context;
        }
        public Task Process(UpdatePerson request, CancellationToken cancellationToken)
        {
            if (string.IsNullOrEmpty(request.CurrentName)) throw new BadHttpRequestException("No name provided");

            if (string.IsNullOrEmpty(request.NewName)) throw new BadHttpRequestException("No new name provided");

            var person = _context.People.AsNoTracking().FirstOrDefault(z => z.Name == request.CurrentName);

            if (person is null) throw new BadHttpRequestException($"Person '{request.CurrentName}' not found");

            return Task.CompletedTask;
        }
    }

    public class UpdatePersonHandler : IRequestHandler<UpdatePerson, UpdatePersonResult>
    {
        private readonly StargateContext _context;

        public UpdatePersonHandler(StargateContext context)
        {
            _context = context;
        }
        public async Task<UpdatePersonResult> Handle(UpdatePerson request, CancellationToken cancellationToken)
        {

            var query = $"SELECT * FROM [Person] WHERE '{request.CurrentName}' = Name";

            var person = await _context.Connection.QueryFirstOrDefaultAsync<Person>(query);

            if (person is not null)
            {
                person.Name = request.NewName;

                _context.People.Update(person);
            }
            else
            {
                throw new BadHttpRequestException("Person not found");
            }

            await _context.Logs.AddAsync(new Log { Success = true, Message = $"Person '{person.Name}' sucessfully changed to '{request.NewName}'", TimeStamp = DateTime.Now });

            await _context.SaveChangesAsync();

            return new UpdatePersonResult()
            {
                Id = person.Id,
                Name = person.Name
            };

        }
    }

    public class UpdatePersonResult : BaseResponse
    {
        public int? Id { get; set; }
        public string? Name { get; set; }
    }
}
