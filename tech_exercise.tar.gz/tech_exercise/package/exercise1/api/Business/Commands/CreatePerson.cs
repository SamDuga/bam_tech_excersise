﻿using MediatR;
using MediatR.Pipeline;
using Microsoft.EntityFrameworkCore;
using StargateAPI.Business.Data;
using StargateAPI.Controllers;

namespace StargateAPI.Business.Commands
{
    public class CreatePerson : IRequest<CreatePersonResult>
    {
        public required string Name { get; set; } = string.Empty;
    }

    public class CreatePersonPreProcessor : IRequestPreProcessor<CreatePerson>
    {
        private readonly StargateContext _context;
        public CreatePersonPreProcessor(StargateContext context)
        {
            _context = context;
        }
        public Task Process(CreatePerson request, CancellationToken cancellationToken)
        {
            if (string.IsNullOrEmpty(request.Name)) throw new BadHttpRequestException("No name provided");

            var person = _context.People.AsNoTracking().FirstOrDefault(z => z.Name == request.Name);            

            if (person is not null && string.Equals(person.Name.ToLower(), request.Name.ToLower())) throw new BadHttpRequestException($"Person '{request.Name}' already exists");

            return Task.CompletedTask;
        }
    }

    public class CreatePersonHandler : IRequestHandler<CreatePerson, CreatePersonResult>
    {
        private readonly StargateContext _context;

        public CreatePersonHandler(StargateContext context)
        {
            _context = context;
        }
        public async Task<CreatePersonResult> Handle(CreatePerson request, CancellationToken cancellationToken)
        {

                var newPerson = new Person()
                {
                   Name = request.Name
                };

                await _context.People.AddAsync(newPerson);

                await _context.Logs.AddAsync(new Log { Success = true, Message = $"Person '{request.Name}' created sucessfully", TimeStamp = DateTime.Now });

                await _context.SaveChangesAsync();

                return new CreatePersonResult()
                {
                    Person = newPerson
                };
          
        }
    }

    public class CreatePersonResult : BaseResponse
    {
        public Person? Person { get; set; }
    }
}
