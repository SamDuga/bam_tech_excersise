﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StargateAPI.Business.Commands;
using StargateAPI.Business.Data;
using StargateAPI.Business.Queries;
using StargateAPI.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace StargateAPI.Tests
{
    [TestClass]
    public class AustronautDutyControllerTests
    {
        private StargateFixture fixture;

        public AustronautDutyControllerTests()
        {
            fixture = new StargateFixture();
        }

        [TestMethod]
        public async Task GetAstronautDutiesByName_returns_all_duties()
        {
            var mediator = ServiceHelper.GetRequiredService<IMediator>();

            var controller = new AstronautDutyController(mediator);

            var buzzResponse = (ObjectResult)await controller.GetAstronautDutiesByName("Buzz Aldrin");
            var buzzResult = (GetAstronautDutiesByNameResult)buzzResponse.Value;

            var neilResponse = (ObjectResult)await controller.GetAstronautDutiesByName("Neil Armstrong");
            var neilResult = (GetAstronautDutiesByNameResult)neilResponse.Value;

            var jimResponse = (ObjectResult)await controller.GetAstronautDutiesByName("Jim Lovell");
            var jimResult = (GetAstronautDutiesByNameResult)jimResponse.Value;

            Assert.IsTrue(buzzResult.AstronautDuties.Count == 3);
            Assert.AreEqual(buzzResult.ResponseCode, 200);
            Assert.AreEqual(buzzResult.Success, true);
            Assert.AreEqual(buzzResult.Message, "Successful");

            Assert.IsTrue(neilResult.AstronautDuties.Count == 2);
            Assert.AreEqual(neilResult.ResponseCode, 200);
            Assert.AreEqual(neilResult.Success, true);
            Assert.AreEqual(neilResult.Message, "Successful");

            Assert.IsTrue(jimResult.AstronautDuties.Count == 0);
            Assert.AreEqual(jimResult.ResponseCode, 200);
            Assert.AreEqual(jimResult.Success, true);
            Assert.AreEqual(jimResult.Message, "Successful");
        }

        [TestMethod]
        public async Task GetAstronautDutiesByName_returns_400_on_invalid_person()
        {
            var mediator = ServiceHelper.GetRequiredService<IMediator>();

            var controller = new AstronautDutyController(mediator);

            var response = (ObjectResult)await controller.GetAstronautDutiesByName("Sam Duga");
            var result = (BaseResponse)response.Value;

            Assert.AreEqual(result.ResponseCode, 400);
            Assert.AreEqual(result.Success, false);
            Assert.AreEqual(result.Message, $"Person 'Sam Duga' not found");
        }

        [TestMethod]
        public async Task GetAstronautDutiesByName_returns_400_on_blank_name()
        {
            var mediator = ServiceHelper.GetRequiredService<IMediator>();

            var controller = new AstronautDutyController(mediator);

            var response = (ObjectResult)await controller.GetAstronautDutiesByName("");

            Assert.AreEqual(response.StatusCode, 400);
            Assert.AreEqual(response.Value, "No name provided");
        }

        [TestMethod]
        public async Task CreateAstronautDuty_creates_new_duty_only()
        {
            var mediator = ServiceHelper.GetRequiredService<IMediator>();

            var controller = new AstronautDutyController(mediator);

            var dutyStartDate = DateTime.Now;  

            var hasOneDetail = fixture.context.AstronautDetails.FromSqlRaw("SELECT * FROM AstronautDetail WHERE PersonId = 2").Count();
            Assert.AreEqual(hasOneDetail, 1);

            var response = (ObjectResult)await controller.CreateAstronautDuty(new CreateAstronautDuty
            {
                Name = "Neil Armstrong",
                Rank = "First Lieutenant",
                DutyTitle = "RETIRED",
                DutyStartDate = dutyStartDate
            });
            var result = (CreateAstronautDutyResult)response.Value;

            Assert.IsNotNull(result.Id);
            Assert.AreEqual(result.ResponseCode, 200);
            Assert.AreEqual(result.Success, true);
            Assert.AreEqual(result.Message, "Successful");

            var stillHasOne = fixture.context.AstronautDetails.FromSqlRaw("SELECT * FROM AstronautDetail WHERE PersonId = 2").Count();
            Assert.AreEqual(stillHasOne, hasOneDetail);

            // teardown
            fixture.context.Database.ExecuteSqlRaw("DELETE FROM AstronautDuty WHERE PersonId = 2 AND DutyTitle = 'RETIRED'");
            fixture.context.Database.ExecuteSqlRaw(
                $"UPDATE AstronautDuty SET Rank = 'First Lieutenant', DutyTitle = 'Media''s favorite astronaut', DutyStartDate = '{dutyStartDate}' WHERE Id = 5");
        }

        [TestMethod]
        public async Task CreateAstronautDuty_creates_new_duty_and_detail()
        {
            var mediator = ServiceHelper.GetRequiredService<IMediator>();

            var controller = new AstronautDutyController(mediator);

            var dutyStartDate = DateTime.Now;

            var noDetail = fixture.context.AstronautDetails.FromSqlRaw("SELECT * FROM AstronautDetail WHERE PersonId = 3").Count();
            Assert.AreEqual(noDetail, 0);

            var response = (ObjectResult)await controller.CreateAstronautDuty(new CreateAstronautDuty
            {
                Name = "Jim Lovell",
                Rank = "First Lieutenant",
                DutyTitle = "Captain",
                DutyStartDate = dutyStartDate
            });
            var result = (CreateAstronautDutyResult)response.Value;

            Assert.IsNotNull(result.Id);
            Assert.AreEqual(result.ResponseCode, 200);
            Assert.AreEqual(result.Success, true);
            Assert.AreEqual(result.Message, "Successful");

            var hasDetail = fixture.context.AstronautDetails.FromSqlRaw("SELECT * FROM AstronautDetail WHERE PersonId = 3").Count();
            Assert.AreEqual(hasDetail, 1);
            Assert.AreNotEqual(hasDetail, noDetail);

            // teardown
            fixture.context.Database.ExecuteSqlRaw("DELETE FROM AstronautDuty WHERE PersonId = 3");
            fixture.context.Database.ExecuteSqlRaw("DELETE FROM AstronautDetail WHERE PersonId = 3");
        }

        [TestMethod]
        public async Task CreateAstronautDuty_rejects_duplicate_duties()
        {
            var mediator = ServiceHelper.GetRequiredService<IMediator>();

            var controller = new AstronautDutyController(mediator);

            var dutyStartDate = new DateTime(1971, 7, 1);

            var response = (ObjectResult)await controller.CreateAstronautDuty(new CreateAstronautDuty
            {
                Name = "Buzz Aldrin",
                Rank = "Brigadier General",
                DutyTitle = "RETIRED",
                DutyStartDate = dutyStartDate
            });
            var result = (BaseResponse)response.Value;

            Assert.AreEqual(result.ResponseCode, 400);
            Assert.AreEqual(result.Success, false);
            Assert.AreEqual(result.Message, $"Duty for 'Buzz Aldrin' with title: 'RETIRED' and start date: {dutyStartDate} already exists");
        }

        [TestMethod]
        public async Task CreateAstronautDuty_returns_400_on_invalid_person()
        {
            var mediator = ServiceHelper.GetRequiredService<IMediator>();

            var controller = new AstronautDutyController(mediator);

            var response = (ObjectResult)await controller.CreateAstronautDuty(new CreateAstronautDuty 
            { 
                Name = "Test",
                Rank = "Colonel",
                DutyTitle = "Orbital Patrol",
                DutyStartDate = DateTime.Now
            });
            var result = (BaseResponse)response.Value;

            Assert.AreEqual(result.ResponseCode, 400);
            Assert.AreEqual(result.Success, false);
            Assert.AreEqual(result.Message, "Person 'Test' not found");
        }
    }
}