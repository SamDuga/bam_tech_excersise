﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.VisualStudio.TestPlatform.TestHost;
using StargateAPI.Business.Commands;
using StargateAPI.Business.Data;
using StargateAPI.Business.Queries;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StargateAPI.Tests
{
    public static class ServiceHelper
    {
        private static IServiceProvider Provider()
        {
            IConfiguration configuration = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                .Build();

            var services = new ServiceCollection();

            services.AddDbContext<StargateContext>(options =>
                options.UseSqlite("DataSource=tubby.db"));

            services.AddMediatR(cfg =>
            {
                cfg.RegisterServicesFromAssemblies(typeof(GetPeopleHandler).Assembly);
                cfg.RegisterServicesFromAssemblies(typeof(GetPersonByNameHandler).Assembly);
                cfg.AddRequestPreProcessor<GetPersonByNamePreProcessor>();
                cfg.RegisterServicesFromAssemblies(typeof(CreatePersonPreProcessor).Assembly);
                cfg.AddRequestPreProcessor<CreatePersonPreProcessor>();
                cfg.RegisterServicesFromAssemblies(typeof(UpdatePersonPreProcessor).Assembly);
                cfg.AddRequestPreProcessor<UpdatePersonPreProcessor>();
                cfg.RegisterServicesFromAssemblies(typeof(CreateAstronautDutyPreProcessor).Assembly);
                cfg.AddRequestPreProcessor<CreateAstronautDutyPreProcessor>();
                cfg.RegisterServicesFromAssemblies(typeof(GetAstronautDutiesByNamePreProcessor).Assembly);
                cfg.AddRequestPreProcessor<GetAstronautDutiesByNamePreProcessor>();
            });            

            return services.BuildServiceProvider();
        }

        public static T GetRequiredService<T>()
        {
            var provider = Provider();

            return provider.GetRequiredService<T>();
        }
    }
}
