﻿using Dapper;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using StargateAPI.Business.Data;

namespace StargateAPI.Tests
{
    public class StargateFixture : IDisposable
    {
        public StargateContext context { get; private set; }

        public StargateFixture()
        {
            var keepAliveConnection = new SqliteConnection("DataSource=tubby.db");
            keepAliveConnection.Open();

            var options = new DbContextOptionsBuilder<StargateContext>()
                .UseSqlite(keepAliveConnection)
                .Options;

            context = new StargateContext(options);

            context.Database.EnsureCreated();

            if (context.People.Count() > 0)
            {
                keepAliveConnection.Execute("DELETE FROM Person");
                keepAliveConnection.Execute("DELETE FROM AstronautDetail");
                keepAliveConnection.Execute("DELETE FROM AstronautDuty");
            }

            context.People.Add(new Person { Id = 1, Name = "Buzz Aldrin" });
            context.People.Add(new Person { Id = 2, Name = "Neil Armstrong" });
            context.People.Add(new Person { Id = 3, Name = "Jim Lovell" });

            context.AstronautDuties.Add(new AstronautDuty
            {
                Id = 1,
                PersonId = 1,
                Rank = "Lieutenant Colonel",
                DutyTitle = "Engineer",
                DutyStartDate = new DateTime(1969, 7, 16),
                DutyEndDate = new DateTime(1969, 7, 24)
            });
            context.AstronautDuties.Add(new AstronautDuty
            {
                Id = 2,
                PersonId = 1,
                Rank = "Colonel",
                DutyTitle = "Hero of the people",
                DutyStartDate = new DateTime(1969, 7, 25),
                DutyEndDate = new DateTime(1971, 6, 30)
            });
            context.AstronautDuties.Add(new AstronautDuty
            {
                Id = 3,
                PersonId = 1,
                Rank = "Brigadier General",
                DutyTitle = "RETIRED",
                DutyStartDate = new DateTime(1971, 7, 1)
            });

            context.AstronautDuties.Add(new AstronautDuty
            {
                Id = 4,
                PersonId = 2,
                Rank = "Second Lieutenant",
                DutyTitle = "Commander",
                DutyStartDate = new DateTime(1969, 7, 16),
                DutyEndDate = new DateTime(1971, 6, 30)
            });
            context.AstronautDuties.Add(new AstronautDuty
            {
                Id = 5,
                PersonId = 2,
                Rank = "First Lieutenant",
                DutyTitle = "Media's favorite astronaut",
                DutyStartDate = new DateTime(1971, 7, 1)
            });

            context.AstronautDetails.Add(new AstronautDetail
            {
                Id = 1,
                PersonId = 1,
                CurrentRank = "Brigadier General",
                CurrentDutyTitle = "RETIRED",
                CareerStartDate = new DateTime(1969, 7, 16),
                CareerEndDate = new DateTime(1971, 7, 1)
            });
            context.AstronautDetails.Add(new AstronautDetail
            {
                Id = 2,
                PersonId = 2,
                CurrentRank = "Second Lieutenant",
                CurrentDutyTitle = "Media's favorite astronaut\"",
                CareerStartDate = new DateTime(1969, 7, 16)
            });

            context.SaveChanges();
        }

        public void Dispose()
        {
            context.Dispose();
        }
    }
}