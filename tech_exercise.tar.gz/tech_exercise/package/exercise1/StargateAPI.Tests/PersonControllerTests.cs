using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StargateAPI.Business.Commands;
using StargateAPI.Business.Queries;
using StargateAPI.Controllers;

namespace StargateAPI.Tests
{
    [TestClass]
    public class PersonControllerTests
    {
        private StargateFixture fixture;

        public PersonControllerTests()
        {
            fixture = new StargateFixture();
        }

        [TestMethod]
        public async Task GetPeople_returns_all_people()
        {
            var mediator = ServiceHelper.GetRequiredService<IMediator>();

            var controller = new PersonController(mediator);

            var response = (ObjectResult)await controller.GetPeople();
            var result = (GetPeopleResult)response.Value;

            Assert.IsTrue(result.People.Count > 0);
            Assert.AreEqual(result.ResponseCode, 200);
            Assert.AreEqual(result.Success, true);
            Assert.AreEqual(result.Message, "Successful");
        }

        [TestMethod]
        public async Task GetPersonByName_returns_null_on_nonexistent_person()
        {
            var mediator = ServiceHelper.GetRequiredService<IMediator>();

            var controller = new PersonController(mediator);

            var response = (ObjectResult)await controller.GetPersonByName("Sam Duga");
            var result = (GetPersonByNameResult)response.Value;

            Assert.IsNull(result.Person);
            Assert.AreEqual(result.ResponseCode, 200);
            Assert.AreEqual(result.Success, true);
            Assert.AreEqual(result.Message, "Successful");
        }

        [TestMethod]
        public async Task GetPersonByName_returns_existing_person()
        {
            var mediator = ServiceHelper.GetRequiredService<IMediator>();

            var controller = new PersonController(mediator);

            var response = (ObjectResult)await controller.GetPersonByName("Buzz Aldrin");
            var result = (GetPersonByNameResult)response.Value;

            Assert.IsNotNull(result.Person);
            Assert.AreEqual(result.ResponseCode, 200);
            Assert.AreEqual(result.Success, true);
            Assert.AreEqual(result.Message, "Successful");
        }

        [TestMethod]
        public async Task GetPersonByName_rejects_empty_names()
        {
            var mediator = ServiceHelper.GetRequiredService<IMediator>();

            var controller = new PersonController(mediator);

            var response = (ObjectResult)await controller.GetPersonByName("");

            Assert.AreEqual(response.StatusCode, 400);
            Assert.AreEqual(response.Value, "No name provided");
        }

        [TestMethod]
        public async Task CreatePerson_makes_new_person()
        {
            var mediator = ServiceHelper.GetRequiredService<IMediator>();

            var controller = new PersonController(mediator);

            var existingCount = fixture.context.People.Count();

            var response = (ObjectResult)await controller.CreatePerson("Sam Duga");
            var result = (CreatePersonResult)response.Value;

            Assert.IsNotNull(result.Person);
            Assert.AreEqual(result.ResponseCode, 200);
            Assert.AreEqual(result.Success, true);
            Assert.AreEqual(result.Message, "Successful");
            Assert.IsTrue(fixture.context.People.Count() > existingCount);

            // teardown
            fixture.context.Database.ExecuteSqlRaw("DELETE FROM Person WHERE Name = 'Sam Duga'");
        }

        [TestMethod]
        public async Task CreatePerson_rejects_existing_people()
        {
            var mediator = ServiceHelper.GetRequiredService<IMediator>();

            var controller = new PersonController(mediator);

            var name = "Buzz Aldrin";

            var response = (ObjectResult)await controller.CreatePerson(name);
            var result = (BaseResponse)response.Value;

            Assert.AreEqual(result.ResponseCode, 400);
            Assert.AreEqual(result.Success, false);
            Assert.AreEqual(result.Message, $"Person '{name}' already exists");
        }

        [TestMethod]
        public async Task UpdatePerson_changes_persons_name()
        {
            var mediator = ServiceHelper.GetRequiredService<IMediator>();

            var controller = new PersonController(mediator);

            var oldName = "Buzz Aldrin";
            var newName = "Brigadir Gen. Buzz Aldrin";

            var response = (ObjectResult)await controller.UpdatePersonByName(oldName, newName);
            var result = (UpdatePersonResult)response.Value;

            Assert.IsNotNull(result.Id);
            Assert.AreEqual(result.ResponseCode, 200);
            Assert.AreEqual(result.Success, true);
            Assert.AreEqual(result.Message, "Successful");
            Assert.AreNotEqual(result.Name, oldName);
            Assert.AreEqual(result.Name, newName);

            // teardown
            fixture.context.Database.ExecuteSqlRaw($"UPDATE PERSON SET Name = '{oldName}' WHERE Name = '{newName}'");
        }

        [TestMethod]
        public async Task UpdatePerson_rejects_empty_names()
        {
            var mediator = ServiceHelper.GetRequiredService<IMediator>();

            var controller = new PersonController(mediator);

            var oldName = "Buzz Aldrin";
            var newName = "Brigadir Gen. Buzz Aldrin";

            var response1 = (ObjectResult)await controller.UpdatePersonByName("", newName);

            var response2 = (ObjectResult)await controller.UpdatePersonByName(oldName, "");

            Assert.AreEqual(response1.StatusCode, 400);
            Assert.AreEqual(response1.Value, "No person name provided");

            Assert.AreEqual(response2.StatusCode, 400);
            Assert.AreEqual(response2.Value, "No new name provided");
        }
    }
}