# Overview

This repository contains a technical exercise that is to be used for reference during a technical interview.
Be prepared to discuss the exercise, the expected results and how you came by them.

## Tasks

1. Follow the instructions in the following folders.  
1. Share the completed exercise back with the person who shared this link with you. (how, is up to you)
